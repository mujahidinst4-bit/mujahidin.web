/*
  ISI dengan Project URL dan Publishable Key dari dashboard Supabase.
  Jangan pernah memasukkan service_role/secret key ke file frontend.
*/
window.SUPABASE_CONFIG = {
  url: "ISI_PROJECT_URL_ANDA",
  anonKey: "ISI_PUBLISHABLE_KEY_ANDA"
};

# Website Pengumpulan Tugas — GitHub Pages + Supabase

## Isi folder
- `index.html`: halaman formulir.
- `style.css`: desain responsif.
- `config.js`: konfigurasi URL dan publishable key Supabase.
- `script.js`: upload file ke Supabase Storage dan simpan metadata ke database.
- `supabase-setup.sql`: SQL awal untuk membuat tabel dan policy demo.

## A. Siapkan Supabase
1. Buat project di https://supabase.com
2. Buka SQL Editor, jalankan seluruh isi `supabase-setup.sql`.
3. Buka Storage > New Bucket.
4. Buat bucket bernama `file-tugas` dan pastikan statusnya **Private**.
5. Ambil Project URL dan Publishable Key dari pengaturan API project.

## B. Konfigurasi frontend
Buka `config.js`, lalu ganti:
- `ISI_PROJECT_URL_ANDA` dengan Project URL Supabase.
- `ISI_PUBLISHABLE_KEY_ANDA` dengan Publishable Key (atau legacy anon key jika project masih menggunakannya).

Jangan masukkan `service_role` key atau secret key ke file frontend.

## C. Uji lokal
Buka folder ini di VS Code dan jalankan `index.html` menggunakan ekstensi Live Server. Isi formulir dan kirim file. Periksa:
- Supabase > Table Editor > `tugas`
- Supabase > Storage > `file-tugas`

## D. Publikasikan ke GitHub Pages
1. Buat repository baru di GitHub.
2. Upload semua file dari folder ini ke root repository.
3. Buka Settings > Pages.
4. Pilih Deploy from a branch.
5. Pilih branch `main` dan folder `/ (root)`, lalu Save.
6. Tunggu deployment selesai. Alamat umumnya:
   `https://USERNAME.github.io/NAMA-REPOSITORY/`

## Catatan keamanan penting
Konfigurasi SQL di paket ini adalah **demo awal**: siapa pun yang mengetahui alamat website dapat mencoba mengirim data dan file. Validasi di browser dapat dilewati, jadi jangan mengandalkannya sebagai perlindungan keamanan.

Sebelum dipakai untuk data kampus sungguhan:
- Tambahkan Supabase Auth untuk mahasiswa dan dosen.
- Batasi upload berdasarkan pengguna yang login, ukuran, tipe MIME, dan pola folder.
- Buat role dosen/admin dan policy RLS khusus.
- Buat halaman admin yang hanya dapat diakses pengguna berwenang.
- Pertimbangkan CAPTCHA/rate limit untuk mengurangi spam.
- Jangan memberi akses publik untuk membaca bucket atau tabel.

Untuk bucket Private, `file_url` berisi path objek, bukan URL publik. File perlu diakses oleh admin yang terautentikasi melalui signed URL atau mekanisme backend yang aman.

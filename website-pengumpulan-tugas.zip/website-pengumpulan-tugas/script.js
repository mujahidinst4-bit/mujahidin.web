const form = document.getElementById("submission-form");
const message = document.getElementById("form-message");
const submitButton = document.getElementById("submit-button");
const buttonText = document.getElementById("button-text");
const fileInput = document.getElementById("file");
const fileLabel = document.getElementById("file-label");

document.getElementById("year").textContent = new Date().getFullYear();

const allowedExtensions = ["pdf", "doc", "docx", "ppt", "pptx", "zip"];
const maxFileSize = 10 * 1024 * 1024;
const config = window.SUPABASE_CONFIG || {};

let supabaseClient = null;

if (
  window.supabase &&
  config.url &&
  config.anonKey &&
  !config.url.includes("ISI_") &&
  !config.anonKey.includes("ISI_")
) {
  supabaseClient = window.supabase.createClient(config.url, config.anonKey);
}

fileInput.addEventListener("change", () => {
  const file = fileInput.files[0];
  fileLabel.textContent = file ? file.name : "Pilih file untuk diunggah";
});

function showMessage(text, type = "") {
  message.textContent = text;
  message.className = `message ${type}`;
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  showMessage("");

  if (!supabaseClient) {
    showMessage("Konfigurasi Supabase belum diisi. Periksa file config.js.", "error");
    return;
  }

  const nama = document.getElementById("nama").value.trim();
  const nim = document.getElementById("nim").value.trim();
  const kelas = document.getElementById("kelas").value.trim();
  const matakuliah = document.getElementById("matakuliah").value.trim();
  const namaTugas = document.getElementById("nama-tugas").value.trim();
  const file = fileInput.files[0];

  if (!file) {
    showMessage("Silakan pilih file tugas terlebih dahulu.", "error");
    return;
  }

  const extension = file.name.split(".").pop().toLowerCase();
  if (!allowedExtensions.includes(extension)) {
    showMessage("Format file tidak didukung.", "error");
    return;
  }
  if (file.size > maxFileSize) {
    showMessage("Ukuran file maksimal 10 MB.", "error");
    return;
  }

  submitButton.disabled = true;
  buttonText.textContent = "Mengirim...";

  let uploadedPath = null;

  try {
    const safeFileName = `${crypto.randomUUID()}.${extension}`;
    uploadedPath = `pengumpulan/${safeFileName}`;

    const { error: uploadError } = await supabaseClient.storage
      .from("file-tugas")
      .upload(uploadedPath, file, {
        cacheControl: "3600",
        upsert: false
      });

    if (uploadError) throw uploadError;

    const { error: insertError } = await supabaseClient
      .from("tugas")
      .insert({
        nama_mahasiswa: nama,
        nim,
        kelas,
        mata_kuliah: matakuliah,
        nama_tugas: namaTugas,
        file_url: uploadedPath
      });

    if (insertError) throw insertError;

    showMessage("Tugas berhasil dikumpulkan. Terima kasih!", "success");
    form.reset();
    fileLabel.textContent = "Pilih file untuk diunggah";
  } catch (error) {
    console.error("Gagal mengirim tugas:", error);

    if (uploadedPath) {
      const { error: cleanupError } = await supabaseClient.storage
        .from("file-tugas")
        .remove([uploadedPath]);
      if (cleanupError) console.error("Gagal membersihkan file:", cleanupError);
    }

    showMessage(error.message || "Terjadi kesalahan saat mengirim tugas.", "error");
  } finally {
    submitButton.disabled = false;
    buttonText.textContent = "Kirim tugas";
  }
});
